# morphogenic_graph_builder_v2_Seek_FIXED.py
import networkx as nx
import json
from datetime import datetime
from sentence_transformers import SentenceTransformer
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity

class MorphogenicGraphBuilder:
    def __init__(self, resonance_map_path, fractal_data_path=None):
        self.graph = nx.MultiDiGraph()
        self.model = SentenceTransformer('all-MiniLM-L6-v2')
        self.resonance_map = self.load_resonance_map(resonance_map_path)
        if fractal_data_path:
            self.fractal_data = self.load_fractal_data(fractal_data_path)
            self.integrate_fractal_data()
        self.add_resonance_map()  # Dodaj atraktory od razu
    
    def load_resonance_map(self, path):
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def load_fractal_data(self, path):
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def add_resonance_map(self):
        """Integruje mapę rezonansową z grafem"""
        for attractor in self.resonance_map['resonance_map']['attractors']:
            self.graph.add_node(
                attractor['id'],
                node_type='attractor',
                **attractor,
                embedding=self.model.encode(attractor['name'] + ' ' + attractor['description'])
            )
    
    def integrate_fractal_data(self):
        """Dodaje dane fraktalne - POPRAWIONA WERSJA"""
        print(f"Ładowanie {len(self.fractal_data)} tematów z danych fraktalnych...")
        
        for word, data in self.fractal_data.items():
            # Dodaj węzeł dla samego słowa
            word_node_id = f"WORD_{word}"
            self.graph.add_node(
                word_node_id,
                node_type='concept',
                word=word,
                frequency=data['frequency'],
                embedding=self.model.encode(word)
            )
            
            # Dodaj triady dla tego słowa
            for i, triad in enumerate(data.get('sample_triads', [])):
                triad_id = f"CRT_{word}_{i}"
                
                # Dodaj węzeł triady
                self.graph.add_node(
                    triad_id, 
                    node_type='CRT',
                    **triad,
                    embedding=self.model.encode(f"{triad['cause']} {triad['core']} {triad['effect']}")
                )
                
                # Połącz słowo z triadą
                self.graph.add_edge(word_node_id, triad_id, weight=0.1, relation='has_triad')
                
                # Połącz triadę z jej komponentami
                self.graph.add_edge(triad['cause'], triad_id, weight=0.1, relation='causal_input')
                self.graph.add_edge(triad_id, triad['effect'], weight=0.1, relation='causal_output')
    
    def connect_triads_to_attractors(self):
        """Łączy wszystkie węzły z atraktorem na podstawie podobieństwa"""
        print("Łączenie węzłów z atraktorem...")
        
        for node_id, node_data in self.graph.nodes(data=True):
            if node_data.get('node_type') in ['CRT', 'concept']:
                node_emb = node_data['embedding']
                
                for attr_id, attr_data in self.graph.nodes(data=True):
                    if attr_data.get('node_type') == 'attractor':
                        similarity = cosine_similarity([node_emb], [attr_data['embedding']])[0][0]
                        
                        # Dla dark attractors - odwrotność podobieństwa
                        if attr_data.get('type') == 'dark':
                            weight = 1 - similarity
                        else:
                            weight = similarity
                        
                        self.graph.add_edge(
                            node_id, attr_id, 
                            weight=weight, 
                            relation='resonance',
                            similarity=float(similarity)
                        )
    
    def analyze_graph(self):
        """Analizuje graf i zwraca podstawowe statystyki"""
        print(f"\n=== ANALIZA GRAFU ===")
        print(f"Liczba węzłów: {self.graph.number_of_nodes()}")
        print(f"Liczba krawędzi: {self.graph.number_of_edges()}")
        
        node_types = {}
        for node_id, data in self.graph.nodes(data=True):
            node_type = data.get('node_type', 'unknown')
            node_types[node_type] = node_types.get(node_type, 0) + 1
        
        print("Typy węzłów:")
        for typ, count in node_types.items():
            print(f"  {typ}: {count}")
        
        return node_types
    
    def find_resonance_paths(self, start_word, max_paths=3):
        """Znajduje ścieżki rezonansu dla danego słowa"""
        start_node = f"WORD_{start_word}"
        
        if start_node not in self.graph:
            print(f"Brak węzła dla słowa: {start_word}")
            return []
        
        paths = []
        light_attractors = [
            node_id for node_id, data in self.graph.nodes(data=True) 
            if data.get('node_type') == 'attractor' and data.get('type') == 'light'
        ]
        
        for target_id in light_attractors:
            try:
                path = nx.shortest_path(self.graph, start_node, target_id, weight='weight')
                path_data = {
                    'path': path,
                    'length': len(path),
                    'target': target_id,
                    'nodes': [self.graph.nodes[node_id] for node_id in path]
                }
                paths.append(path_data)
            except nx.NetworkXNoPath:
                continue
        
        return sorted(paths, key=lambda x: x['length'])[:max_paths]

    # Tymczasowe rozsunięcie atraktorów w przestrzeni
    def reposition_attractors(self):
        """Rozsuwa atraktory w przestrzeni embeddingów"""
        attractors = [n for n, d in self.graph.nodes(data=True) 
                     if d.get('node_type') == 'attractor']
        
        for i, attr_id in enumerate(attractors):
            # Przesuń każdy atractor w innym kierunku
            shift = np.random.normal(0, 0.5, 384)  # 384 = wymiar embeddingu
            self.graph.nodes[attr_id]['embedding'] += shift * (i + 1)

    def visualize(self, output_path='test_graph.html'):
        """Poprawiona wizualizacja z obsługą błędów PyVis"""
        try:
            from pyvis.network import Network
            net = Network(notebook=False, height='800px', width='100%', directed=True)
            
            # Dodaj węzły z kolorami wg typu
            for node, data in self.graph.nodes(data=True):
                color = self.get_node_color(data.get('node_type'))
                net.add_node(node, label=node, color=color, 
                            title=str(data)[:100])  # Tooltip z danymi
                
            # Dodaj krawędzie z wagami
            # for u, v, data in self.graph.edges(data=True):
            #     net.add_edge(u, v, value=data.get('weight', 0.1), 
            #                 title=f"weight: {data.get('weight', 0.1):.3f}")
            

            # Dodaj krawędzie z wagami korekta GA
            for u, v, data in self.graph.edges(data=True):
                # Pobierz wagę i skonwertuj ją na standardowy typ float
                weight_value = float(data.get('weight', 0.1)) 

                net.add_edge(u, v, value=weight_value, 
                title=f"weight: {weight_value:.3f}")


            # Zapisz z obsługą błędów
            net.save_graph(output_path)
            print(f"Wizualizacja zapisana: {output_path}")
            return True
            
        except Exception as e:
            print(f"Błąd wizualizacji: {e}")
            print("Ale graf jest poprawnie zbudowany - kontynuujemy bez wizualizacji")
            return False

    def get_node_color(self, node_type):
        """Przypisuje kolory wg typu węzła"""
        colors = {
            'attractor': '#ff6b6b',
            'CRT': '#4ecdc4', 
            'concept': '#45b7d1',
            'unknown': '#96ceb4'
        }
        return colors.get(node_type, '#f9c74f')

# PRZYGOTOWANY PRZYKŁAD UŻYCIA
if __name__ == "__main__":
    print("=== MORPHOGENIC GRAPH BUILDER - TEST ===")
    
    try:
        # 1. Inicjalizacja builder'a
        builder = MorphogenicGraphBuilder('first_prototype.json', 'themes_niezwyciezony.json')
        
        # 2. Analiza początkowego grafu
        builder.analyze_graph()
        
        # 3. Łączenie z atraktorem
        builder.connect_triads_to_attractors()
        
        # 4. Analiza po połączeniu
        print("\nPo połączeniu z atraktorem:")
        builder.analyze_graph()
        
        # 5. Test - znajdź ścieżki dla przykładowego słowa
        test_words = ['ludzie', 'system', 'technologia']  # Przykładowe słowa z Lema
        for word in test_words:
            print(f"\n=== ŚCIEŻKI REZONANSOWE DLA: '{word}' ===")
            paths = builder.find_resonance_paths(word)
            
            if paths:
                for i, path in enumerate(paths):
                    print(f"Ścieżka {i+1}:")
                    print(f"  Długość: {path['length']} kroków")
                    print(f"  Cel: {path['target']}")
                    print(f"  Trasa: {' -> '.join(path['path'])}")
            else:
                print(f"  Brak ścieżek do light attractorów")
        
        # testowe rozsunięcie
        builder.reposition_attractors()
        
        # 6. Próba wizualizacji
        print("\n=== PRÓBA WIZUALIZACJI ===")
        builder.visualize('test_graph.html')
        
    except FileNotFoundError as e:
        print(f"Błąd: Nie znaleziono pliku - {e}")
        print("Upewnij się, że pliki 'first_prototype.json' i 'themes_niezwyciezony.json' są w bieżącym katalogu")
    except Exception as e:
        print(f"Błąd podczas uruchamiania: {e}")
        import traceback
        traceback.print_exc()